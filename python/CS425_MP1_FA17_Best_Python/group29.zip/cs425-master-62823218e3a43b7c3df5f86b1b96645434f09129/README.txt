This is the implementation of MP1. 

===SETUP===
./kill.sh to kill all running server sessions
./deploy.sh to distribute executable files to all machines
./boot.sh to start all server sessions 

===QUERY===
python3.6 MP1/client.py $file_path $reg_ex
Output will be redirected to outputs folder

===TEST===
python3.6 MP1/test.py

Please let us know if you have any question. {dlei5, qzhu3}@illinois.edu