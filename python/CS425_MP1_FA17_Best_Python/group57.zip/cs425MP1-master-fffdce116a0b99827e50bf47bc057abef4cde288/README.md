#### README
### This is the readme file for fa2017 CS425 MP1 Group57{stang30, yumochi2}

1. requirements 
	This submission is written in python 2.7 and bash, so there is no need to compile anything. However to run the bash script you need to install `pssh` from `sudo pip install pssh`

2. running the main code ## 
	MP1.py is the main script to run log collector on VMs. It has both server and client side implementation. Fetched logs will be stored in a log file using python `logging` module, default store log file name is `DS.log`.  

	For the rest of code we assume you are in `$cs425MP1/src` as `$ROOT` directory.  
	1 To run the log collector on server side, use command `$ROOT$python MP1.py -s` on any of the VMs.  
	2 To collect log from a list of VMs, login to one VM and use
	`$ROOT$python MP1.py -k <search keyword> -n <a list of node id seperated by space>`. For example, `$ROOT$python MP1.py -k 404 -n 01 02 03 04` for search and fetch all "404" logs in node 01,02,03,04.  
	3 To specified log directory use argument keywork `-d`, for example `$ROOT$python MP1.py -s -d ./DS_server.log` will create and store all server side log infomation on `DS_server.log`. For other argument please check MP1.py for more details.  

3. run and kill processe on mutiple VMs with one script  
	We also provide a bash script `runOnVms.sh` to call and kill `MP1.py` process on multiple VMs. To use this script:  

	1 first change variable `$U` to change username.  
	2 commment/uncommnet variable `$NUM` to specify which set of VMs you want to operate.  
	3 `$ROOT$ ./runOnVMs.sh run` will run log collector servers on target VMs,  not adding any argument or `$ROOT$ ./runOnVMs.sh kill` will try to kill server side processed on VMs.

4. perform grep on multiple servers' logfile
    likewise use bash script `runOnVms.sh` to run and kill `MP1.py` process on other VMS. to use this script:

    1. Git pull corresponding `MP1.py` on desired VMs. Besure to use the correct branch so `MP1.py` will contain correct pathing for log files, located on line 274.
    2. Change the corresponding pathing for `runOnVms.sh` on lines 34 and 36.
    3. Add DS_server.log to each corresponding VMs. 
    4. run `MP1.py` on desired VMs using `runOnVms.sh`
    5. run `MP1.py` to initiate grep using the command `python MP1.py -k <keyword to search> -n <corresponding VMS>`. The keyword refers to desired search pattern and the VMS are just the virtual machine the user wish to perform grep on. For
    use `python MP1.py -k 404 -n 01 02 03 04` to perform grep for '404' on VMs 01, 02, 03, 04.
    6. kill `MP1.py` on correspond VMs.



