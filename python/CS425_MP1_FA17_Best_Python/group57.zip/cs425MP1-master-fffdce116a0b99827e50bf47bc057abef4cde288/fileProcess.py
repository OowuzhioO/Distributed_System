with open("epa-http.txt") as f:
    content = f.readlines()
# you may also want to remove whitespace characters like `\n` at the end of each line
size = len(content)
newSize = int(size/10)
print(size)
print(newSize)
n = 0
firstFile = True;
for i in range(size):
	if i % newSize == 0:
		if(not firstFile):
			firstFile = False
			f.close() 
		n += 1
		filename1 = "epa-http"
		filename2 = ".txt" 
		f = open('logs/'+filename1 + "-" + str(n) + filename2, 'w')
	f.write(content[i])  # python will convert \n to os.linesep
