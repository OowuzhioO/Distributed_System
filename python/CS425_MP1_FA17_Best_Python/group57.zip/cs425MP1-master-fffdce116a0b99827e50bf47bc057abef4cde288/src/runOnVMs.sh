#!/bin/bash

# 'run' for running server otherwise kill all servers in VMs

U=$1
MODE=$2
IFTEST=$3


host_file='pssh_ds_hosts'

rm $host_file


declare -a NUM=('01' '02' '03' '04' '05' '06' '07' '08' '09' '10')
# declare -a NUM=('01' '02' '03' '04' '05')


for i in "${NUM[@]}"
do
  host='fa17-cs425-g57-'"$i"'.cs.illinois.edu'
  echo $host:22 >>$host_file
done


if [ "$MODE" = "run" ]; then
    #using pssh to run MP1 script on VM nodes
    echo "Runing log servers on VMs"
    if [ "$IFTEST" = 'test' ]; then
    	echo 'Run servers for unit testing'
        # for unit test
        pssh -h $host_file -l $U  -i 'cd ./cs425MP1/src && rm ./DS_server.log && python MP1.py -s -d ./DS_server.log -l ../logs'
   
    else
        pssh -h $host_file -l $U  -i 'cd ./cs425MP1/src && rm ./DS_server.log && python MP1.py -s -d ./DS_server.log'
    fi

else
    # kill MP1 process on VMs
    echo "Kill log servers on VMs"
    pssh -h $host_file -l $U  -i "pkill -f MP1"
fi

rm $host_file