from collections import OrderedDict
import socket
import threading
import subprocess
from time import localtime, strftime
import time
import logging

import os, sys
import argparse
import struct

import pdb
import pprint

VM_DICT = {'raamac3147':'localhost'} # for debug
VM_DICT.update({socket.gethostname():'localhost'})
NodeLogFiles = {'localhost':'../logs/epa-http-2.txt'}

def stampedMsg(msg):
	return strftime("[%Y-%m-%d %H:%M:%S] ", localtime())+msg


class DSlog_collector(object):
	def __init__(self, VM_DICT, NodeLogFiles,host='localhost', port=9888, num_VMs=9):
		self.host = host
		self.port = port
		self.num_VMs =num_VMs
		self.bufsize = 4096
		self.nodeName = VM_DICT[socket.gethostname()]
		self.NodeLogFiles = NodeLogFiles
		self.log_dir = self.NodeLogFiles[self.nodeName]
		self.NodeId2HostName = {v:k for k,v in VM_DICT.items()}
		self.VM_DICT = VM_DICT
		self.msgStartToken = '<msg_starts>'
		self.msgEndToken = '<msg_ends>'

	def encodeLen(self,content):
		return struct.pack('>I', len(content)) + content

	def process(self,cmd):
		# TODO: check cmd format, if it's a string and if it's valid to parse
		# also check if log file directory is valid
		# return empty string if not grep results can be found on such log file
		content = '[Empty]'
		# check if log files on this node
		if not os.path.isfile(self.log_dir):
			return self.encodeLen('Error : Designated log file {} does not exist on node:{}'.format(self.log_dir, self.nodeName))

		cmdlist= cmd.split(':')
		if len(cmdlist)<2:
			return self.encodeLen('Error : {} is not an legal input'.format(cmd))

		clientNode = cmdlist[0]
		cmd_string = ':'.join(cmdlist[1:])
		cmd_string = cmd_string.strip() ## remove \n if present
		logging.info(stampedMsg('Receiving follwing request from node: {}'.format(clientNode)))
		logging.info('grep keyword: '+cmd_string)

		if not cmd_string:
			return self.encodeLen('Error : {} is not valid cmd'.format(cmd_string))

		# with open(self.log_dir, 'rb') as f:
		# 	content = f.read()
		try:
			content = subprocess.check_output(['grep', cmd_string, self.log_dir])
		except subprocess.CalledProcessError as e:
			if e.returncode ==1:
				content = "Error : No match found"
			elif e.returncode>1:
				content = 'Error : An grep error occurred'


		#add identifier to check message compeleteness
		content = self.msgStartToken+content+self.msgEndToken 

		# pdb.set_trace()
		# Prefix each message with a 4-byte length (network byte order)
		# content = struct.pack('>I', len(content)) + content

		return self.encodeLen(content)
		

	def server(self):
		sckt = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		sckt.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
		sckt.bind((self.host, self.port))
		sckt.listen(self.num_VMs) ## listen to the rest of 9 VMs
		
		# keep receiving msgs from other VMs
		while True:
			conn, addr = sckt.accept()
			rmtHost= socket.gethostbyaddr(addr[0])[0]
			logging.debug(stampedMsg('Server connected by {}').format(addr))
			while True:
				try:
					cmd = conn.recv(self.bufsize)
				except socket.error, e:
					logging.warning("Caught exception socket.error : %s" %e)
					logging.warning(stampedMsg('Fail to receive signal from clients {}'.format(rmtHost)))
					break

				if not cmd:					
					logging.debug(stampedMsg('Receiving stop signal from clients {}'.format(rmtHost)))
					break
				# Do something with  received msg
				try:
					msg2client = self.process(cmd)
					# pdb.set_trace()
					conn.sendall(msg2client)
					logging.debug(stampedMsg('Msg send to {} successfully'.format(rmtHost)))
				except socket.error, e:
					logging.warning("Caught exception socket.error : %s" %e)
					logging.warning(stampedMsg('Msg fail sending to {}'.format(rmtHost)))

			logging.debug(stampedMsg('Closing server on {}:{}\n'.format(self.host, self.port)))	
			conn.close()

	# broadcast func
	def requestLogFromNodes(self,nodes,kw, logNames):
		port=self.port
		total_line_count = 0
		start_time = time.time()

		# output query results
		lines_ = []


		for i, node in enumerate(nodes):

			nodeName = 'Node'+node if node !='localhost' else node

			if not nodeName in self.NodeId2HostName.keys():
				print '{} is not on the node name list'.format(nodeName)
				continue 

			nodeAddr = socket.gethostbyname(self.NodeId2HostName[nodeName])
			log = logging.getLogger(logNames[i])
			success, line_count = self.requestLogOnce(hostname=nodeName,host=nodeAddr,port=port,cmd=kw,log=log)
			total_line_count+=line_count
			lines_.append(line_count)
			print 'loginfo: Node {} has {} lines for keyword: {}'.format(nodeName, line_count, kw)

		elapsed = time.time()-start_time

		print 'Total line count for in all queried nodes: {}, program elapsed in {:.4f}s, see log file for more details'.format(total_line_count, elapsed) 
		return lines_

	def requestLogOnce(self, hostname, host, port, cmd,log):
		sckt = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		line_count=0

		# connect to server
		logging.info(stampedMsg('Client {} connecting to {}({}:{})'.format(self.nodeName,hostname,host,port)))
		try:
			sckt.connect((host,port))
			log.debug(stampedMsg('Client connected'))
		except socket.error, e:
			sckt.close()
			log.warning("Caught exception socket.error : %s" %e)
			log.warning(stampedMsg('Can not connect to {}({}:{})\n'.format(hostname, host,port)))
			return -1,line_count

		#send cmd
		try:
			sckt.sendall(self.nodeName+':'+cmd)
			# receive log from server
			# loginfo= sckt.recv(self.bufsize)
			loginfo = self.recvMsg(sckt)
			log.info(stampedMsg('Search keyword: {}'.format(cmd)))
			success, line_count = self.push2log(loginfo, host,hostname,log)
			log.debug(stampedMsg('log received from {} done\n'.format(hostname)))
		except socket.error, e:
			sckt.close()
			log.warning("Caught exception socket.error : %s" %e)
			log.warning(stampedMsg('Fail to send msg to {}:{}\n'.format(host,port)))
			return -1,line_count


		sckt.close()
		return 1, line_count

	def recvMsg(self,sckt):
		raw_msgLen = self.recvall(sckt,4)
		if not raw_msgLen:
			return None
		msgLen = struct.unpack('>I',raw_msgLen)[0]
		return self.recvall(sckt, msgLen)

	def recvall(self,sckt,n):
		data = ''
		while len(data) < n:
		    packet = sckt.recv(n - len(data))
		    if not packet:
		        return None
		    data += packet
		return data		

	def push2log(self,loginfo,rmthost,hostname, log):
		# TODO: 
		# parse loginfo in the the desired format
		line_count = 0

		if not loginfo:
			log.warning(stampedMsg('Empty loginfo received from {}\n'.format(hostname)))
			return -1,line_count

		# check message start and end token to check message intergrity
		if not loginfo.startswith(self.msgStartToken):
			log.critical(stampedMsg('Retreived message missing start token! Raw message will be logged'))
			log.critical(stampedMsg(loginfo))
			return -1,line_count

		loginfo = loginfo.replace(self.msgStartToken,'')

		# pdb.set_trace()

		if not loginfo.endswith(self.msgEndToken):
			log.warning(stampedMsg('Retreived message missing end token! All received message will be logged'))
		else:
			loginfo = loginfo.replace(self.msgEndToken,'')


		# pdb.set_trace()
		line_count = len(loginfo.splitlines()) if not loginfo.startswith('Error') else 0
		log.info(stampedMsg('The following info received from {} ({} lines)'.format(hostname, line_count)))

		loginfo = '#'*30+'\n'+loginfo +'\n'+'#'*35
		log.info(loginfo)

		return 1, line_count


def setup_logger(logger_name, log_file, level=logging.INFO):
    l = logging.getLogger(logger_name)
    formatter = logging.Formatter('%(levelname)s:%(message)s')
    fileHandler = logging.FileHandler(log_file, mode='w+')
    fileHandler.setFormatter(formatter)
    fileHandler.setLevel(level)

    streamHandler = logging.StreamHandler(stream=None)
    streamHandler.setFormatter(formatter)
    streamHandler.setLevel(logging.ERROR)
  


    l.setLevel(level)
    l.addHandler(fileHandler)
    l.addHandler(streamHandler)
    

if __name__ == '__main__':

	parser = argparse.ArgumentParser()
	parser.add_argument("--node_log_dir",'-l',type=str, default='../fetched_logs')
	parser.add_argument('--DSlog','-d', type=str,default='./DS.log')
	parser.add_argument("--server",'-s', action='store_true')
	parser.add_argument("--verbose", '-v', action='store_true')

	if ('--server' not in sys.argv) and ('-s' not in sys.argv): 
		parser.add_argument("--keyword",'-k',type=str, required=True)
		parser.add_argument("--nodes",'-n',nargs='+', required=True)

	args = parser.parse_args()
	# pdb.set_trace()

	log_dir = args.node_log_dir
	log_collector_dir = args.DSlog
	loggingLevel = logging.DEBUG if args.verbose else logging.INFO
	logging.basicConfig(format='%(levelname)s:%(message)s', filename=log_collector_dir,level=loggingLevel)
	
	
	# VM map, host name to node names
	VM_DICT.update(OrderedDict({'fa17-cs425-g57-%02d.cs.illinois.edu'%i:'Node%02d'%i for i in range(1,11)}))
	NodeLogFiles.update(OrderedDict({'Node%02d'%i:os.path.join(log_dir,'vm%d.log'%i) for i in range(1,11)}))

	DSLogger = DSlog_collector(host=socket.gethostbyname(socket.gethostname()),VM_DICT=VM_DICT,NodeLogFiles=NodeLogFiles)

	if args.server:
		
		# create DS log collector if not exists
		if not os.path.exists(log_collector_dir):
			file = open(log_collector_dir, 'w+')

		logging.info(stampedMsg('Starting log collector'))
		logging.info(stampedMsg('Server Running'))
		print stampedMsg('Server Running')
		DSLogger.server()

	else:
		lg = log_collector_dir.split('.')
		logNames = []
		for node in args.nodes:
			this_log_path = '.'.join(lg[:-1])+node+'.log'
			logName = 'log_'+node
			setup_logger(logName,this_log_path)
			logNames.append(logName)
		# pdb.set_trace()

		lines = DSLogger.requestLogFromNodes(nodes=args.nodes,kw = args.keyword, logNames=logNames)
		

	





	


