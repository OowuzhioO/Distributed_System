# unit tests for MP1.py
# minimum requried unit test:

# 1. generate new log files using old log with randomly generated new lines 
# 2. use scp copy them to servers
# 3. using subprocess call MP1.py and query for keywords, store line count output
# 4. locally count new logs, compare with results from MP1.py


from MP1 import DSlog_collector, setup_logger
import logging
import os, sys
import numpy as np
import subprocess
import random
from collections import OrderedDict
import socket

import pdb

log_dir = '../logs'
log_collector_dir = './test_DS.log'
nodes = ['01','02','03','04','05']
keyword = '40412314'

def get_path(name):
	return os.path.join(log_dir,name)

def genNewLogs(seed=1):
	remote_rsts=[]

	random.seed=seed
	np.random.seed = seed
	# old logs
	num_randlog = 300
	randsource_file_name = get_path('epa-http-11.txt')
	with open(randsource_file_name,'r') as f:
		content = np.array(f.read().splitlines())

	for i, node in enumerate(nodes):
		oldlogname = get_path('epa-http-%d.txt'%(i+1))
		newlogname = get_path('vm%d.log'%(i+1))

		with open(oldlogname,'r') as f:
			oldlog = f.read().splitlines()

		idx = np.random.permutation(len(content))[:num_randlog]
		# pdb.set_trace()
		rand_cont = content[idx]
		oldlog.append(rand_cont)

		with open(newlogname,'w') as f:
			for line in oldlog:
				print>>f,line

		# scp to VM's directory
		subprocess.call(['scp', newlogname, 'stang30@fa17-cs425-g57-%02d.cs.illinois.edu:~/cs425MP1/logs'%(i+1)])
		# remote grep keyword
		# cmd = 'ssh stang30@fa17-cs425-g57-%02d.cs.illinois.edu grep "./cs425MP1/logs/vm%d.log | wc -l"'%((i+1),(i+1))
		# print cmd
		# cmd_al = 'ssh stang30@fa17-cs425-g57-01.cs.illinois.edu grep 404 ./cs425MP1/logs/vm1.log| wc -l'
		remote_line_count=subprocess.check_output(['ssh','stang30@fa17-cs425-g57-%02d.cs.illinois.edu'%(i+1), 'grep '+keyword+' ./cs425MP1/logs/vm%d.log | wc -l'%(i+1)])
		# print remote_line_count
		remote_rsts.append(int(remote_line_count.strip()))
	return remote_rsts


def testMP1(nodes,keyword):


	loggingLevel = logging.DEBUG
	logging.basicConfig(format='%(levelname)s:%(message)s', filename=log_collector_dir,level=loggingLevel)
	logger = logging.getLogger()
	logger.disabled = True
	VM_DICT={'raamac3147':'localhost'}
	NodeLogFiles={'localhost':'../logs/epa-http-2.txt'}

	VM_DICT.update(OrderedDict({'fa17-cs425-g57-%02d.cs.illinois.edu'%i:'Node%02d'%i for i in range(1,11)}))
	NodeLogFiles.update(OrderedDict({'Node%02d'%i:os.path.join(log_dir,'vm%d.log'%i) for i in range(1,11)}))


	# print NodeLogFiles

	lg = log_collector_dir.split('.')
	logNames = []


	for node in nodes:
		this_log_path = '.'.join(lg[:-1])+node+'.log'
		logName = 'log_'+node
		setup_logger(logName,this_log_path)
		logNames.append(logName)

	DSLogger = DSlog_collector(host=socket.gethostbyname(socket.gethostname()),VM_DICT=VM_DICT,NodeLogFiles=NodeLogFiles)
	# print DSLogger.log_dir
	lines = DSLogger.requestLogFromNodes(nodes=nodes,kw = keyword, logNames=logNames)

	return nodes,lines

def compareRsts(nodes, lines_loc, lines_remote):
	assert len(nodes) == len(lines_loc)
	assert len(lines_loc) == len(lines_remote)
	for i, node in enumerate(nodes):
		print 'validation for node:{}'.format(node)
		assert lines_loc[i] == lines_remote[i]
		print 'keyword:{} locally:{}, remote:{}'.format(keyword, lines_loc[i], lines_remote[i])
		print 'pass'

	print 'Unit test passed!'


keywords = ['404', '200', '^www[0~99]']
for k in keywords:
	keyword = k
	lines_remote = genNewLogs()
	nodes, lines_loc = testMP1(nodes=nodes, keyword=keyword)
	compareRsts(nodes, lines_loc, lines_remote)