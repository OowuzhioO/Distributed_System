g++ -O3 -o send send.cpp ../udp/socketlib.cpp -std=c++11
g++ -O3 -o recv recv.cpp ../udp/socketlib.cpp -std=c++11
