g++ -O3 -o dgrep dgrep.cpp -std=c++11 -pthread
g++ -O3 -o dgrep_daemon worker.cpp
