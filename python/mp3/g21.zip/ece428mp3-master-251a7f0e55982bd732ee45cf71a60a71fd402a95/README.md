This is the readme for ECE428's MP3- by Kevin Guo (kguo10) and Mrigank Bhardwaj (mbhwardw2)

SETTING UP:
----------------------------------------------------------------------------------------------------------
The MP3 is split into 7 files;
    4 python files:
        cloud.py                - the file you should call to start the program
        global_vars.py          - global variables
        membership.py           - file which holds contents of MP2
        filesys.py              - file which holds bulk of MP3, the filesystem part
    3 shell script:
        transfer_put.sh         - a script called for 'put' operations
        transfer_get.sh         - a script called for 'get' operations
        transfer_cloud.sh       - a script called for reduplicating

Make sure all of these files are in the same directory together!
In addition make sure you have the following directories together:
    MP3                         - holds all files above for MP3
    file_storage                - holds all relevant local files, as well as distributed SDFS files
    file_storage/local          - holds all relevant local files to put into or get from SDFS
    file_storage/cloud          - holds all SDFS files
    log_directory               - contains logfile we write into (and can use MP1's distributed grep on)

Once you've got the above setup, you're ready to go! Python doesn't need to compile ;D

RUNNING:
----------------------------------------------------------------------------------------------------------
Run "python cloud.py" from your first machine in the MP3 directory to create a new network.

For every subsequent machine, run "python cloud.py [x]", where [x] is the hostname number of any machine
currently running in the network you want to link up to. Remember, the filesys will only work with 3 or more
machines, and heartbeating/failure detection will only start to work when there are 5 or more machines.

Once you've got your desired network up and running, you can type commands to run. The commands are:
MEMBERSHIP STUFF:
    membership                  - displays the current membership list, with timestamps, of this node's network,
                                  neighbors are marked as (nodeID) and current node is marked as [nodeID]
    swid                        - prints the node number we currently are in the membership list
    hwid                        - prints our hardwareID (the part of hostname that identifies each machine)
    leave                       - causes the node to gracefully leave the system

FILESYS STUFF:
    cloud                       - displays all files in the distributed system, along with their replica nodes
    store                       - displays all files replicated in the SDFS on that node (file_storage/cloud)
    local                       - displays all local files on that node (file_storage/local)
    ls [arg1]                   - displays all machines storing filename 'arg1'
    put [arg1] [arg2]           - puts local file 'arg1' into the distributed system as name 'arg2'
    get [arg1] [arg2]           - gets file in the SDFS named 'arg1' and copies it into local file system as 'arg2'
    delete [arg1]               - deletes file in the SDFS with name 'arg1'

and of course, CTRL-C to crash. ;D
