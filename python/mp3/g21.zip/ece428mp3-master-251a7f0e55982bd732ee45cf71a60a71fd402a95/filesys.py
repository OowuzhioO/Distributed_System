import sys
import os
import subprocess
import socket
import time
import threading
import logging
import signal   # send signal "kill -10 [PID]" to terminate process gracefully
import hashlib
import select

import global_vars
import membership

enableOutput = True

# This funciton hashes a replica to a node
# SDFSFileKey --> the sdfs filename we're finding a replica for
# replicaNum --> specifies which replica we need to fill (replica 1, 2, or 3)
# returns: the node that we should put this replica on
def generateReplica(SDFSFileKey, replicaNum):
    nodeListLen = len(global_vars.nodeList)
    if((replicaNum > 3) or (replicaNum < 1)) or (SDFSFileKey not in global_vars.SDFS) or (nodeListLen < 3):
        return -1
    return (hash(SDFSFileKey) - (replicaNum - 1)) % len(global_vars.nodeList)

# This function hashes a replica to a node.
# It doesn't require a replicaNum, it just increments the nodenumber (within boundaries of nodelist)
# until our new generated node is no longer in the SDFS dictionary
# INPUT: SDFSFileKey to hash
# OUTPUT: A corresponding hashed node guaranteed to not collide with an existing node for that key,
#         or -1 if the key is not in our SDFSdict, OR all nodes are taken and we can't guarantee a new node
def generateNonConflictingReplica(SDFSFileKey):
    nodeListLen = len(global_vars.nodeList)
    if (SDFSFileKey not in global_vars.SDFS) or (len(global_vars.SDFS[SDFSFileKey][1]) >= nodeListLen):
        return -1
    node = hash(SDFSFileKey) % nodeListLen
    while (global_vars.nodeList[node][15:17] in global_vars.SDFS[SDFSFileKey][1]):
        if(enableOutput):
            print "node {} clashes".format(node)
            logging.info("node {} clashes".format(node))
        node = (node + 1) % nodeListLen
    if(enableOutput):
        print "returning node {}".format(node)
        logging.info("returning node {}".format(node))
    return node

def compressedSDFS():
    compressedSDFS = ""
    for key, value in global_vars.SDFS.iteritems():
        compressedSDFS = compressedSDFS + "{}:{}:".format(key, value[0]) # file:timestamp:
        for val in value[1]:
            compressedSDFS = compressedSDFS + val + "," # file:timestamp:rep1,rep2,rep3
        compressedSDFS = compressedSDFS + " " # entries separated by a space
        if(enableOutput):
            print compressedSDFS
        # each entry: "file:timestamp:rep1,rep2,rep3 file1:timestamp1:rep11,rep12,rep13"
    return compressedSDFS

# This helper function handles all backend file system operations
# input: string message, socket object
# output: 1 if it handled a message, 0 if it didn't
def backendFilesys(message, addr, sys_sock):
    # This command means somebody thinks we're a master, and they want a timestamp. send it back only to them
    if(message.startswith("timestamp")):
        timestamp = time.time()
        sys_sock.sendto(str(timestamp), addr)

    # This command means that the master has received a request for a file insert/modification.
    # It's purpose is to update the timestamp in our SDFS dict.
    elif(message.startswith("insertFile")):
        message = message[11:].split()
        if(message[0] not in global_vars.SDFS):
            if(enableOutput):
                print "Adding new entry ({} with timestamp {}) to SDFS".format(message[0], message[1])
                logging.info("Adding new entry ({} with timestamp {}) to SDFS".format(message[0], message[1]))
            global_vars.SDFS[message[0]] = [message[1], []]
        else:
            if(enableOutput):
                print global_vars.SDFS[message[0]]
                logging.info("Updating old entry ({} with timestamp {}) to SDFS".format(message[0], message[1]))
                print "Updating old entry ({} with timestamp {}) to SDFS".format(message[0], message[1])
            global_vars.SDFS[message[0]][0] = message[1]

    # This command means that a node somewhere has confirmed receipt of a new file.
    # That means we are adding this node to a certain file's dict entry.
    elif(message.startswith("confirm")): # msg format: g"confirm:[filename] [replica node]"
        message = message[8:].split()
        logging.debug("confirm message is {}".format(message))
        if(message[0] in global_vars.SDFS):
            if(enableOutput):
                print "File {} finished copying in node {}".format(message[0], message[1])
                logging.info("File {} finished copying in node {}".format(message[0], message[1]))
            if(message[1] not in global_vars.SDFS[message[0]][1]):
                global_vars.SDFS[message[0]][1].append(message[1])
        else:
            print "Filename not in SDFS data structure"

    # This command means we want to copy a file from cloud to local directory
    elif(message.startswith("copy_local")):
        message = message[11:].split()
        if(enableOutput):
            print "copy_local message is {}".format(message)
        if(message[0] in global_vars.SDFS):
            if(enableOutput):
                print "sending file"
            timestamp = grabTimestamp(message[0])
            if(enableOutput):
                print "command is: ./transfer_get.sh {} {} {} {}".format(message[2], message[0], message[1], timestamp)
                logging.info("command is: ./transfer_get.sh {} {} {} {}".format(message[2], message[0], message[1], timestamp))
            subprocess.Popen(["./transfer_get.sh", message[2], message[0], message[1], timestamp, global_vars.hardwareID], stdout=subprocess.PIPE)
        else:
            print "file not found in global dict"

    # 'died' and 'leave' message is for membership, but we also need to handle it
    elif(message.startswith("died")) or (message.startswith("leave")):
        willRehash = False
        indexToRehash = -1
        if(enableOutput):
            for key, value in global_vars.SDFS.iteritems():
                print "{} {}".format(key, value)
        for key, value in global_vars.SDFS.iteritems():
            if(enableOutput):
                logging.info("Checking {} file".format(key))
                print "Checking {} file".format(key)
            willRehash = False
            indexToRehash = -1
            for i in range(len(value[1])):
                if(value[1][i] == global_vars.nodeList[global_vars.selfPos][15:17]):
                     # print "Current node has file {}".format(key)
                    willRehash = True
                #print "Checking if node {} with message {} is 1".format(node, message[5:])
                if(value[1][i] in message[5:38]):
                    if(enableOutput):
                        print "Need to rehash {} because node {} died".format(key, message[5:38])
                        logging.info("Need to rehash {} because node {} died".format(key, message[5:38]))
                    indexToRehash = i
                    # need to rehash the current key (file)
            if((indexToRehash >= 0) and (willRehash == True)):
                newReplica = generateNonConflictingReplica(key)
                if(enableOutput):
                    logging.info("Generating new replica and sending to {}".format(global_vars.nodeList[newReplica]))
                    logging.info("command is ./transfer_cloud.sh {} {} {} {} {}".format(global_vars.nodeList[newReplica][15:17], key, key, value[0], global_vars.hardwareID))
                    print "Generating new replica and sending to {}".format(global_vars.nodeList[newReplica])
                    print "command is ./transfer_cloud.sh {} {} {} {} {}".format(global_vars.nodeList[newReplica][15:17], key, key, value[0], global_vars.hardwareID)
                subprocess.Popen(["./transfer_cloud.sh", global_vars.nodeList[newReplica][15:17], key, key, grabTimestamp(key), global_vars.hardwareID])#, stdout=subprocess.PIPE)#, stderr=subprocess.PIPE)
                #global_vars.SDFS[key][1][indexToRehash] = newReplica #<----- THIS SHOULDN'T BE HERE. ONLY BEEN ADDED FOR TESTING PURPOSES
            if(indexToRehash >= 0):
                value[1].remove(value[1][indexToRehash]) # removing the dead node from the list

    # This means that a node wants to join the system. Send them the SDFS dict
    elif(message.startswith("info")):
        if(enableOutput):
            logging.info("Received info request for the SDFS")
            print "Received info request for the SDFS"
        # compress sdfs list and send it over
        if(bool(global_vars.SDFS)):
            sdfspacket = compressedSDFS()
            sys_sock.sendto(sdfspacket, addr)
        else:
            sys_sock.sendto("sdfsempty", addr)

    # This command means we want to delete a file from the SDFS. If it's in our cloud directory, remove it from there, too.
    elif(message.startswith("del_file")):
        message = message[9:].split()
        if(enableOutput):
            logging.info("del message is {}".format(message))
            print "del message is {}".format(message)
        if(message[0] in global_vars.SDFS):
            global_vars.SDFS.pop(message[0])
        deleteFile(message[0])
    else:
        return 0
    return 1

# This helper function handles all user input pertaining to the file system
# input: string cmd, socket object sys_sock
# output: 1 if it handled a message, 0 if it didn't (or if message can be processed by others)
def filesysUI(cmd, UISock):
    # "put" command takes a file from local dir and puts it onto the CLOUD!
    # format: "put localfilename sdfsfilename"
    if(cmd.startswith("cloud")):
        for key, value in global_vars.SDFS.iteritems():
            print "{} {}".format(key, value)
    elif(cmd.startswith("store")):
        for filename in os.listdir("../file_storage/cloud/"):
            print filename
    elif(cmd.startswith("local")):
            for filename in os.listdir("../file_storage/local/"):
                print filename
    elif(cmd.startswith("ls")):
        if(len(cmd.split()) < 2):
            print "Command requires more arguments"
            return 1
        filesearch = cmd.split()
        if(filesearch[1] not in global_vars.SDFS):
            print "File not found"
            return 1
        for value in global_vars.SDFS[filesearch[1]][1]:
            print "fa17-cs425-g21-{}.cs.illinois.edu".format(value)
    elif(cmd.startswith("put")):
        if(len(cmd.split()) < 3):
            print "Command requires more arguments"
            return 1
        localfilename = cmd.split()[1]
        sdfsfilename = cmd.split()[2]
        # Check for existence of file in local folder
        if localfilename not in os.listdir("../file_storage/local/"):
            print "File {} does not exist in local directory".format(localfilename)
            return 1

        # Grab the master timestamp, keep trying to get a reply until a master responds (deals with master crashes)
        UISock.settimeout(5.0) # Keep trying to get a reply until a master responds (deals with master crashes)
        while(True):
            try:
                if(enableOutput):
                    print "We are going to machine {}".format(global_vars.nodeList[0].split()[0])
                UISock.sendto("timestamp:", (global_vars.nodeList[0].split()[0], global_vars.systemChangePort))
                masterTime, addr = UISock.recvfrom(1024)
            except socket.timeout:  # If socket times out, try again
                pass
            else:
                break   # If no errors occur, break the loop and don't try again
        if(enableOutput):
            print "Received timestamp {} from master".format(masterTime)

        # If the file already exists, check if it was last modified more than 60 seconds ago
        if sdfsfilename in global_vars.SDFS:
            if(enableOutput):
                print ("times {} > {}").format(float(global_vars.SDFS[sdfsfilename][0])+60.0, float(masterTime))
        if sdfsfilename in global_vars.SDFS and float(global_vars.SDFS[sdfsfilename][0])+60.0 > float(masterTime):
            # If the file does exist, check the timestamp, and read in the servers
            print "Last modification to '{}' was {} seconds ago. Proceed? (y/n)".format(sdfsfilename, float(masterTime) - float(global_vars.SDFS[sdfsfilename][0]))
            i, o, e = select.select([sys.stdin], [], [], 30)
            if (i):
                if sys.stdin.readline().strip() == 'y':
                    print "Proceeding with file modification"
                else:
                    print "File modification rejected"
                    return 1
            else:
                print "30-second timeout: update rejected"
                return 1

        # Check if the SDFSname already exists in our SDFS dict
        if sdfsfilename not in global_vars.SDFS or len(global_vars.SDFS[sdfsfilename][1]) == 0:
            # If the filename does not exist in our dictionary, then add it, and generate servers for it
            print "Adding new file to SDFS: {}".format(sdfsfilename)
            global_vars.SDFS[sdfsfilename] = [masterTime, []]
            replica1 = generateReplica(sdfsfilename, 1)
            replica2 = generateReplica(sdfsfilename, 2)
            replica3 = generateReplica(sdfsfilename, 3)
            if(enableOutput):
                print "Replica 1: {}, Replica 2: {}, Replica 3: {}".format(replica1, replica2, replica3)
            if((replica1 * replica2 * replica3) < 0): # in other words, if any of the replica functions returned -1
                print "ERROR: Replica generation invalid"
                return 1
            server1 = global_vars.nodeList[replica1][15:17]
            server2 = global_vars.nodeList[replica2][15:17]
            server3 = global_vars.nodeList[replica3][15:17]
        else:
            # Read in the servers. If we have less than 3 servers, return bad!
            if len(global_vars.SDFS[sdfsfilename][1]) < 3:
                print "ERROR: There are {} server(s) for {}".format(len(global_vars.SDFS[sdfsfilename][1]), sdfsfilename)
                return 1
            server1 = global_vars.SDFS[sdfsfilename][1][0]
            server2 = global_vars.SDFS[sdfsfilename][1][1]
            server3 = global_vars.SDFS[sdfsfilename][1][2]
        if(enableOutput):
            print "Server 1: {}, Server 2: {}, Server 3: {}".format(server1, server2, server3)

        # Send out insertFile request to all nodes
        membership.sendMessageToAll("insertFile:" + sdfsfilename + " " + masterTime)

        # Now here we do the scp/ftp/ssh/uiuc/wtfkindaprotocolthing to ship files to the replicas
        subprocess.Popen(["./transfer_put.sh", server1, localfilename, sdfsfilename, masterTime, global_vars.hardwareID])#, stdout=subprocess.PIPE)#, stderr=subprocess.PIPE)
        subprocess.Popen(["./transfer_put.sh", server2, localfilename, sdfsfilename, masterTime, global_vars.hardwareID])#, stdout=subprocess.PIPE)#, stderr=subprocess.PIPE)
        subprocess.Popen(["./transfer_put.sh", server3, localfilename, sdfsfilename, masterTime, global_vars.hardwareID])#, stdout=subprocess.PIPE)#, stderr=subprocess.PIPE)
        # Wait until we've received confirmation that two of the three entries in our SDFS dictionaries have been filled
        global_vars.SDFS[sdfsfilename][1] = []
        while(len(global_vars.SDFS[sdfsfilename][1]) < 2):
            time.sleep(2);
        print "File write successful!"
        logging.debug("File write {} successful!".format(sdfsfilename))

    # "get" command takes a file from the sdfs and downloads it to local
    # format: "get sdfsfilename localfilename"
    elif(cmd.startswith("get")):
        if(len(cmd.split()) < 3):
            print "get command invalid"
            return 1
        sdfsfilename = cmd.split()[1]
        localfilename = cmd.split()[2]
        # Check for existence in directory
        if (sdfsfilename not in global_vars.SDFS):
            print "no such file exists in the cloud..."
            return 1
        elif len(global_vars.SDFS[sdfsfilename][1]) < 2:
            print "only {} file replicas exist in the cloud".format(len(global_vars.SDFS[sdfsfilename][1]))
            return 1
        else:
            # If a file exists, send a request message to a quorum of nodes (2/3 of nodes)
            node0 = "fa17-cs425-g21-{}.cs.illinois.edu".format(global_vars.SDFS[sdfsfilename][1][0])
            node1 = "fa17-cs425-g21-{}.cs.illinois.edu".format(global_vars.SDFS[sdfsfilename][1][1])
            if(enableOutput):
                print "Sending requests to: {} {}".format(node0[15:17], node1[15:17])
            UISock.sendto("copy_local: {} {} {}".format(sdfsfilename, localfilename, global_vars.hardwareID), (node0, global_vars.systemChangePort))
            UISock.sendto("copy_local: {} {} {}".format(sdfsfilename, localfilename, global_vars.hardwareID), (node1, global_vars.systemChangePort))
        # And now we wait for the files to come in!
        global_vars.gotFile = 0
        print "Waiting for file transfer operations to complete"
        start = time.time()
        while(time.time() - start) < 30.0:    # set timeout of 30 seconds
            if global_vars.gotFile >= 2:
                print "Get operation complete"
                pruneLocal()
                return 1
        print "Timeout in file get operation: {} files got.".format(global_vars.gotFile)

    # "delete" command will send a message to all nodes to delete a certain file
    elif(cmd.startswith("delete")):
        if(len(cmd.split()) < 2):
            print "delete command invalid"
            return 1
        sdfsfilename = cmd.split()[1]
        # Check for existence in directory
        if (sdfsfilename not in global_vars.SDFS):
            print "no such file exists in the cloud..."
        else:
            membership.sendMessageToAll("del_file:{}".format(sdfsfilename))

    else:
        return 0
    return 1

def fileMaintainer():
    # First, delete all cloud storage in our node.
    file_list = os.listdir("../file_storage/cloud/")
    for filename in file_list:
        os.remove("../file_storage/cloud/" + filename)

    # Loop and constantly prune the files in the cloud directory
    while(True):
        time.sleep(1)
        pruneCloud()
        time.sleep(1)
        pruneLocal()


# This helper function will remove all file duplicates and files with old timestamps in the cloud directory
# Will keep timestamps after pruning, because it deals with the cloud
# input: none
# output: none
def pruneCloud():
    file_list = os.listdir("../file_storage/cloud/")
    for filename in file_list:
        # if("a.txt" in filename):
        #     print "File {} is currently in the cloud directory".format(filename)
        first_file = filename.split(':')
        if len(first_file) == 3 and first_file[0] == "new":
            if(enableOutput):
                print "Found a file that starts with 'new': {}".format(filename)
            os.rename("../file_storage/cloud/" + filename, "../file_storage/cloud/" + filename[4:])
            if(enableOutput):
                print "FILE {} received with TIMESTAMP {}".format(first_file[2], first_file[1])
            # Send indicator to all nodes we have received a file
            membership.sendMessageToAll("confirm:" + " " + first_file[2] + " " + global_vars.hardwareID)
            file_list.remove(filename)
            file_list.append(filename[4:])
        elif filename == " + filename":
            if(enableOutput):
                print "We have a duplicate file {}".format(filename)
            os.remove("../file_storage/cloud/" + filename)
            file_list.remove(filename)
        elif len(first_file) == 2:
            for filename2 in file_list:
                second_file = filename2.split(':')
                # Check to make sure the file names are the same, but the files aren't
                if len(second_file) == 2 and filename != filename2 and first_file[1] == second_file[1]:
                    if(enableOutput):
                        print "Found duplicate files with different timestamps {} and {}".format(filename, filename2)
                    # Check to see who has the most recent timestamp
                    if float(first_file[0]) >= float(second_file[0]):
                        if(enableOutput):
                            print "OLD FILE {} with TIMESTAMP {} being REMOVED".format(second_file[1], second_file[0])
                        os.remove("../file_storage/cloud/" + filename2)
                        file_list.remove(filename2)
                    else:
                        if(enableOutput):
                            print "OLD FILE {} with TIMESTAMP {} being REMOVED".format(first_file[1], first_file[0])
                        os.remove("../file_storage/cloud/" + filename)
                        file_list.remove(filename)

# This helper function will remove all file duplicates and files with old timestamps in the local directory
# Will not keep timestamps after pruning, and may remove older non-timestamped files
def pruneLocal():
    file_list = os.listdir("../file_storage/local/")
    for filename in file_list:
        first_file = filename.split(':')
        if len(first_file) == 3 and first_file[0] == "new":
            os.rename("../file_storage/local/" + filename, "../file_storage/local/" + filename[4:])
            if(enableOutput):
                print "FILE {} received with TIMESTAMP {}".format(first_file[2], first_file[1])
            # Increment our gotfile indicator for local receipt
            global_vars.gotFile += 1
            file_list.remove(filename)
            file_list.append(filename[4:])
        elif filename == " + filename":
            os.remove(dir_path + filename)
            file_list.remove(filename)
        elif len(first_file) == 2:
            for filename2 in file_list:
                second_file = filename2.split(':')
                # Check to make sure the file names are the same, but the files aren't
                if len(second_file) == 2 and filename != filename2 and first_file[1] == second_file[1]:
                    # Check to see who has the most recent timestamp
                    if float(first_file[0]) >= float(second_file[0]):
                        if(enableOutput):
                            print "OLD FILE {} with TIMESTAMP {} being REMOVED".format(second_file[1], second_file[0])
                        os.remove(dir_path + filename2)
                        file_list.remove(filename2)
                    else:
                        if(enableOutput):
                            print "OLD FILE {} with TIMESTAMP {} being REMOVED".format(first_file[1], first_file[0])
                        os.remove(dir_path + filename)
                        file_list.remove(filename)

    # Now remove any timestamps, possibly replacing files
    for filename in os.listdir("../file_storage/local/"):
        file_split = filename.split(':')
        if len(file_split) == 2:
            print "RENAMING {} with TIMESTAMP {} ".format(file_split[1], file_split[0])
            os.rename("../file_storage/local/" + filename, "../file_storage/local/" + file_split[1])

# This helper function will return a file's timestamp, given the name
# input: string filename
# output: string timestamp
def grabTimestamp(origFile):
    # First, prune the directory so we get rid of any duplicates
    pruneCloud()
    file_list = os.listdir("../file_storage/cloud/")
    for filename in file_list:
        file_split = filename.split(':')
        if origFile == file_split[1]:
            return file_split[0]

# This helper function will delete a file in the cloud, given a name (no timestamp needed)
# input: a string filename
# output: none
def deleteFile(origFile):
    pruneCloud()
    file_list = os.listdir("../file_storage/cloud/")
    for filename in file_list:
        file_split = filename.split(':')
        if origFile == file_split[1]:
            if(enableOutput):
                print "DELETING {}".format(filename)
            os.remove("../file_storage/cloud/" + filename)
            return

# This function sets up all the necessary work and threads we'll need for the filesys
def setupFilesystem():
    fileMaintenanceThread = threading.Thread(target=fileMaintainer)
    fileMaintenanceThread.daemon = True
    fileMaintenanceThread.start()

if __name__ == '__main__':
    # Start the logging
    print "Huskies are swag."
    print "Go execute 'cloud.py' instead."
