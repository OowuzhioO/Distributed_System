#!/bin/sh

# This script is a 'get' wrapper for SCP. It prefixes a file "inprogress: " while copying, and then
# renames the prefix to "new: " when it's done copying.
# It copies from file_storage/cloud to file_storage/local

# $0 name of program
# $1 node we want to send to
# $2 filename we are copying from
# $3 filename we are copying to
# $4 timestamp we are copying
# $5 the HW ID we are sending from

scp -o "StrictHostKeyChecking=no" -i ../../428key ../file_storage/cloud/"${4}:${2}" kguo10@fa17-cs425-g21-${1}.cs.illinois.edu:ECE428/file_storage/local/"inprogress:${4}${5}:${3}"
ssh -o "StrictHostKeyChecking=no" -i ../../428key kguo10@fa17-cs425-g21-${1}.cs.illinois.edu "cd ECE428/file_storage/local && mv 'inprogress:${4}${5}:${3}' 'new:${4}${5}:${3}'"
