import sys
import socket
import os
import subprocess
import time
import threading
import logging

import global_vars

enableOutput = True

# This function makes sure we receive heartbeats from every neighbor at least once every 2 seconds
# input: no input
# returns: should never return
def heartbeatMonitor():
    # declare systemChanged as global
    global systemChanged

    # First create a socket and attach it to the heartbeat port to listen
    try:
        h = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        logging.debug("Heartbeat monitoring socket created")
    except socket.error as err:
        if(enableOutput):
            print "Socket creation failed with error %s" %err
        logging.critical("Socket creation failed with error %s" %err)

    h.bind(('', global_vars.heartbeatPort))
    logging.info("Heartbeat monitoring socket binded.")
    print "Heartbeat monitoring socket created and binded."

    while(True):
        nodeListCopy = global_vars.nodeList[:]  # make copy of list so later deletes won't affect us
        selfPosCopy = global_vars.selfPos
        if len(global_vars.nodeList) >= 5:      # Make sure we have at least 5 nodes
            start = time.time()
            # Create a dictionary to check off heartbeats from neighbors
            nodeListChecker = {circularList(selfPosCopy-2,nodeListCopy):0,
                               circularList(selfPosCopy-1,nodeListCopy):0,
                               circularList(selfPosCopy+1,nodeListCopy):0,
                               circularList(selfPosCopy+2,nodeListCopy):0}

            # In ranges of 5 seconds, check heartbeats from our neighbors
            while(time.time() - start) < 5.0:
                heartbeat, addr = h.recvfrom(1024)
                if heartbeat in nodeListChecker:
#                    print 'heartbeat {} was received from {}'.format(heartbeat, addr)
                    logging.debug('heartbeat {} was received from {}'.format(heartbeat, addr))
                    nodeListChecker[heartbeat] = 1

            if(global_vars.systemChanged == 1):
                logging.debug('System changed, restarting loop')
                global_vars.systemChanged = 0
                continue
#            print nodeListChecker
            # If a neighbor is not checked in within 2 seconds, remove them!
            for key, value in nodeListChecker.iteritems():
                if value is 0:
                    if(enableOutput):
                        print 'FOUND DEAD NEIGHBOR {}'.format(key)
                    logging.info('FOUND DEAD NEIGHBOR {}'.format(key))
#                    global_vars.nodeList.remove(key)     # we don't kill here because we'll kill it later
                    # and send a message to everybody!
                    sendMessageToAll("died:" + key)

# server process that sends heartbeats back to the client process that connected to this
# This function takes care of sending heartbeats once a second to our two adjacent neighbors
# input: no input
# returns: should never return
def heartbeatSender():
    while(True):
        try:
            sender = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            logging.debug("Heartbeat monitoring socket created")
        except socket.error as err:
            print "Socket creation failed with error %s" %err
            logging.critical("Socket creation failed with error %s" %err)

        sender.settimeout(0.5)
        nodeListCopy = global_vars.nodeList[:]  # make copy of list so later deletes won't affect us
        selfPosCopy = global_vars.selfPos
        try:
            if len(global_vars.nodeList) >= 5:      # Make sure we have at least 5 nodes
                for i in [-2,-1,1,2]:
                    logging.debug('Starting on neighbor {}'.format(i))
                    neighborID = circularList(selfPosCopy+i,nodeListCopy)
                    dest = neighborID.split()[0]
                    logging.debug('about to send')
                    n = sender.sendto(global_vars.nodeList[selfPosCopy], (dest, global_vars.heartbeatPort))
                    logging.debug('sent')
    #                print '{} heartbeat bytes were sent to {}'.format(n,dest)
                    logging.info('{} heartbeat bytes were sent to {}'.format(n,dest))
            else:
                logging.debug('List is less than 5 nodes: {}'.format(global_vars.nodeList))
            time.sleep(0.5)
            logging.debug('Reached end of neighbor list')
        except Exception as err:
            print('BAD THINGS: {}'.format(err))
            logging.critical('BAD THINGS: {}'.format(err))
            time.sleep(0.5)

# This function uses python's default list, from global_vars.nodeList, to implement a circular list.
# input: index in list we want to access
# output: value stored in that index
def circularList(index, linear_list):
    if len(linear_list) > 0:
        circularIndex = (index) % len(linear_list)
        return linear_list[circularIndex]
    return -1

# debug helper function to print our current global_vars.nodeList
# input: node
# returns: nothing
def printList():
    if(enableOutput):
        print "Machine List: ".format(socket.gethostname())
        nodeListCopy = global_vars.nodeList[:]  # make copy of list so later deletes won't affect us
        for i in range(len(global_vars.nodeList)):
            if i is global_vars.selfPos:
                print ' [{}]: {}'.format(i, global_vars.nodeList[i])
            elif global_vars.nodeList[i] in [circularList(global_vars.selfPos-2,nodeListCopy),
                                 circularList(global_vars.selfPos-1,nodeListCopy),
                                 circularList(global_vars.selfPos+1,nodeListCopy),
                                 circularList(global_vars.selfPos+2,nodeListCopy)]:
                print ' ({}): {}'.format(i, global_vars.nodeList[i])
            else:
                print '  {} : {}'.format(i, global_vars.nodeList[i])
        print "We are at pos %d"%(global_vars.selfPos)
    logging.debug('List is currently: {}'.format(global_vars.nodeList))

# This function 'compresses' a list to send over a socket to a newly joined node
def compressList(nodelist):
    retString = ""
    for node in nodelist:
        retString += (node + ",")
    retString = retString[:-1]
    return retString

# This helper function takes in a system message and sends it to every node in our membership list,
# including ourselves, but ony last.
# input: string message
# returns: nothing
def sendMessageToAll(message):
    try:
        send = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        logging.debug("System message socket created.")
    except socket.error as err:
        print "Socket creation failed with error %s" %err
        logging.critical("Socket creation failed with error %s" %err)
    nodeListCopy = global_vars.nodeList[:]  # make copy of list so later deletes won't affect us
    for nodeid in nodeListCopy:
        dest = nodeid.split()[0]
        if dest != global_vars.hostname:
            n = send.sendto( message, (dest, global_vars.systemChangePort))
            logging.debug('Sent {} system-update bytes to {}'.format(n, dest))
    n = send.sendto(message, (global_vars.hostname, global_vars.systemChangePort))
    logging.debug('Sent {} system-update bytes to ourselves'.format(n))
    send.close()

# This helper function handles all membership system changes
# input: string message, socket object
# output: 1 if it handled a message, 0 if it didn't
def messageHandler(message, addr, sys_sock):
    if(message.startswith("join")):
        if(enableOutput):
            print "\nReceived join request and notifying all nodes..."
        logging.info("Received join request and notifying all nodes...")
        nodeID = message[5:] + ' ' + str(time.time())
        # Notify all existing processes of its new neighbor
        sendMessageToAll("add:"+nodeID)
        # Add new node to own list and send entire list to new node
        global_vars.nodeList.append(nodeID)
        if(enableOutput):
            print "Added node to own list"
        logging.debug("Added node to own list")
        listPacket = compressList(global_vars.nodeList)
    #            print "listPacket is {}".format(listPacket)
        printList()
        sys_sock.sendto(listPacket, addr)
        global_vars.systemChanged = 1
    elif(message.startswith("add")):  # check for new nodes from our introducer
        if message[4:] in global_vars.nodeList:
            # print "Received add command for {}, but ignoring.".format(message[4:])
            logging.info("Received add command for {}, but ignoring.".format(message[4:]))
        else:
            if(enableOutput):
                print "Received add command for {}, and adding.".format(message[4:])
            logging.info("Received add command for {}, and adding".format(message[4:]))
            global_vars.nodeList.append(message[4:]) # add nodeID to our list
            printList()
            global_vars.systemChanged = 1
    elif(message.startswith("leave")):  # check for nodes which announced their departure
        if message[6:] == global_vars.nodeList[global_vars.selfPos]:    # check if the supposedly leaving is OURSELVES
            if(enableOutput):
                print "Server shutting down gracefully!"
            logging.info("Server shutting down gracefully!")
            sys.exit()
        elif message[6:] in global_vars.nodeList:     # check if we haven't already removed it
            if(enableOutput):
                print "Received leave command for node {}, and removing:".format(message[6:])
            logging.info("Received leave command for node {}, and removing:".format(message[6:]))
            if(global_vars.nodeList.index(message[6:]) < global_vars.selfPos):
                #print "Decrementing our self pos because the node removed is less than our own"
                logging.info("Decrementing our self pos because the node removed is less than our own")
                global_vars.selfPos = global_vars.selfPos - 1
            global_vars.nodeList.remove(message[6:])
            printList()
            global_vars.systemChanged = 1
            return 0
        else:
            logging.info("Received leave command for {}, but ignoring.".format(message[4:]))

    elif(message.startswith("died")):
        # If network latency gets really bad, then other nodes might think we ded.
        # If that happens, let's just kill ourselves to prevent other problems.
        if message[5:] == global_vars.nodeList[global_vars.selfPos]:    # check if the supposedly dead is OURSELVES
            if(enableOutput):
                print "We're killing ourselves!"
            logging.critical("We're killing ourselves!")
            sys.exit()
        if message[5:] in global_vars.nodeList:     # check if we haven't already removed it
            if(enableOutput):
                print "Received death command for node {}, and removing:".format(message[5:])
            logging.info("Received death command for node {}, and removing:".format(message[5:]))
            if(global_vars.nodeList.index(message[5:]) < global_vars.selfPos):
                #print "Decrementing our self pos because the node removed is less than our own"
                logging.info("Decrementing our self pos because the node removed is less than our own")
                global_vars.selfPos = global_vars.selfPos - 1
            global_vars.nodeList.remove(message[5:])
            printList()
            global_vars.systemChanged = 1
            return 0
        else:
            logging.info("Received death command for {}, but ignoring.".format(message[4:]))
    elif(message.startswith("info")):   # check for info requests from a joining introducer
        if(enableOutput):
            print "Received info {} request from: {}".format(message, addr)
        logging.info("Received info request {} from: {}".format(message, addr))
        listPacket = compressList(global_vars.nodeList)
        sys_sock.sendto(listPacket, addr)  # compress and send our current knowledge
        return 0
    else:
        return 0
    return 1


# This sets up the membership lists for failure detection
def setupMembership(s, nodeNumber):
    # Now, see if we need to gather the current process list from somewhere"
    if(nodeNumber != -1):
        infoNode = "fa17-cs425-g21-{:02}.cs.illinois.edu".format(nodeNumber)
        if(enableOutput):
            print("Gathering information from {}:".format(infoNode))
        logging.info("Gathering information from {}:".format(infoNode))
        n = s.sendto("info:" + socket.gethostname(), (infoNode, global_vars.systemChangePort))

        # Grab the current list of nodes
        s.settimeout(5.0)   # set timeout if our desired node doesn't respond
        compressedList = s.recvfrom(1024)[0]
        if(enableOutput):
            print "Received compressed list from node!"
        logging.info("Received compressed list from node!")
        global_vars.nodeList = str(compressedList).split(",")

        s.settimeout(5.0)   # set timeout if our desired node doesn't respond
        compressedSDFS = s.recvfrom(1024)[0]
        if(compressedSDFS != "sdfsempty"):
            entries = compressedSDFS.split()
            for entry in entries:
                file_info = entry.split(':')
                global_vars.SDFS[file_info[0]] = [file_info[1], []]
                replicas = file_info[2].split(',')
                for i in range(len(replicas) - 1):
                    global_vars.SDFS[file_info[0]][1].append(replicas[i])
        else:
            if(enableOutput):
                print "SDFS is currently empty"
            logging.info("SDFS is currently empty")

    # Now append ourselves onto the system.
    if(sys):
        nodeID = socket.gethostname() + ' ' + str(time.time())
        global_vars.nodeList.append(nodeID)
        global_vars.selfPos = len(global_vars.nodeList) - 1
        printList()
        sendMessageToAll("add:"+nodeID)
        if(enableOutput):
            print "Successfully joined the system!"
        logging.info("Successfully joined the system!")

    # Now it's time to create our other two heartbeat sending+monitoring threads
    heartbeatSenderThread = threading.Thread(target=heartbeatSender)
    heartbeatSenderThread.daemon = True
    heartbeatSenderThread.start()
    heartbeatMonitorThread = threading.Thread(target=heartbeatMonitor)
    heartbeatMonitorThread.daemon = True
    heartbeatMonitorThread.start()

# This is the main failure detecting thread
def failureDetector(sock):
    # Now just sit and receive system messages
    sock.settimeout(None)
    while True:
        message, addr = sock.recvfrom(1024)
        # message format --> [type]:[hostname] i.e. "join:fa17-cs425-g21-01.cs.illinois.edu"
        if messageHandler(message, addr, sys_sock):
            logging.info("Handled membership system message")
        else:   # mention if we got any other unexpected messages
            print "Received unusual message: {}".format(message)
            logging.info("Received unusual message: {}".format(message))

# This is the loop which handles user IO for membership-related things
# input: string cmd, socket object sys_sock
# output: 1 if it handled a message, 0 if it didn't (or if message can be processed by others)
def userIO(cmd, UISock):
    if(cmd.startswith("membership")):
        printList();
        return 1
    elif(cmd.startswith("swid")):
        print "Software ID is: {}".format(global_vars.selfPos)
        return 1
    elif(cmd.startswith("hwid")):
        print "Hardware ID is: {}".format(global_vars.hardwareID)
        return 1
    elif(cmd.startswith("leave")):
        print "Server preparing to shut down."
        sendMessageToAll("leave:" + global_vars.nodeList[global_vars.selfPos])
        return 1
    return 0

# This is the main thread, and we only want membership, not file stuff
if __name__ == '__main__':
    # Start the logging
    logging.basicConfig(format='%(asctime)s: %(message)s', datefmt='%m-%d-%Y %H:%M:%S',
    filename='../log_directory/logfile.log', filemode='w', level=logging.DEBUG)

    # See this next line if we modify how processes are started for MP3 (delegation of master status)
    nodeNumber = -1
    if(len(sys.argv) == 2):
        nodeNumber = int(sys.argv[1])

    # Connect our system-change socket
    try:
        sys_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        logging.debug("System message socket created.")
    except socket.error as err:
        print "Socket creation failed with error %s" %err
        logging.critical("Socket creation failed with error %s" %err)
    sys_sock.bind(('', global_vars.systemChangePort))
    logging.info("System message socket binded.")
    sys_sock.settimeout(None)

    # Set up our membership
    sys_sock = setupMembership(nodeNumber)

    failureDetector(member)
