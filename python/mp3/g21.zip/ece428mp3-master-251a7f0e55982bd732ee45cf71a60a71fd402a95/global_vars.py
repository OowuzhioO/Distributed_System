# This file holds all global variables that may be used across multiple files

# MEMBERSHIP:
nodeList = []           # list of all nodes in our system
selfPos = 0             # current position in our nodeList
systemChanged = 0       # flag that indicates whether a change has occurred in our membership list
heartbeatPort = 12345   # This port is for heartbeat receiving

# FILESYS:
SDFS = {}               # Dictionary of format filename : [timestamp,[replica1,replica2,replica3]]
SDFSPort = 12347        # This port is for SDFS operations
gotFile = 0             # This flag indicates how many files we've 'got' from a get operation

# OTHER:
hardwareID = ""             # Our hardware id, EG the number "02" in hostname "fa17-cs425-g21-02.cs.illinois.edu"
hostname = ""
systemChangePort = 12346    # This port is for system-change messages
