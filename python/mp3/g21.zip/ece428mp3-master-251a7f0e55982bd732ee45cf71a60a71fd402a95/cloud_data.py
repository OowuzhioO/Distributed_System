import sys
import os
import subprocess
import socket
import time
import threading
import logging
import signal   # send signal "kill -10 [PID]" to terminate process gracefully
import hashlib

import global_vars
import membership
import filesys_datacollection

systemChangePort = 12346    # This is for system-change messages
userIOPort = 12348          # This is for sending user-triggered messages

def system_loop(sys_sock):
    sys_sock.settimeout(None)
    while True:
        message, addr = sys_sock.recvfrom(1024)
        # Failure Detector message format --> [type]:[hostname] i.e. "join:fa17-cs425-g21-01.cs.illinois.edu"
        # Cloud message format --> put:filename,
        if membership.messageHandler(message, addr, sys_sock):
            logging.info("Handled membership system message")
        # ------------------------------------------ CLOUD COMMANDS -----------------------
        elif filesys_datacollection.backendFilesys(message, addr, sys_sock):
            logging.info("Handled filesystem message")
        else:
            print "Received unusual system message: {}".format(message)
            logging.info("Received unusual system message: {}".format(message))

def input_loop(UISock):
    print "Welcome to the SDFS"
    while True:
        cmd = raw_input("SDFS> ")
        if membership.userIO(cmd, UISock):
            logging.info("Handled user input for membership")
        elif filesys_datacollection.filesysUI(cmd, UISock):
            logging.info("Handled user input for filesys")
        elif cmd == '':
            pass
        else:
            print("Unrecognized command")

if __name__ == '__main__':
    # Start the logging
    logging.basicConfig(format='%(asctime)s: %(message)s', datefmt='%m-%d-%Y %H:%M:%S',
    filename='../log_directory/logfile.log', filemode='w', level=logging.DEBUG)

    # Initialize our hardware ID number and hostname:
    global_vars.hostname = socket.gethostname()
    global_vars.hardwareID = global_vars.hostname[15:17]

    # See this next line if we modify how processes are started for MP3 (delegation of master status)
    nodeNumber = -1
    if(len(sys.argv) == 2):
        nodeNumber = int(sys.argv[1])

    # Connect our system and user sockets
    try:
        sys_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        UISock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        logging.debug("System and user sockets created.")
    except socket.error as err:
        print "Socket creation failed with error %s" %err
        logging.critical("Socket creation failed with error %s" %err)
    sys_sock.bind(('', systemChangePort))
    UISock.bind(('', userIOPort))
    logging.info("System and user sockets binded.")

    # Set up our membership lists
    membership.setupMembership(sys_sock, nodeNumber)

    # Set up our file systems
    filesys_datacollection.setupFilesystem()

    # Start our user input loop thread
    userIOThread = threading.Thread(target=input_loop, args=(UISock, ))
    userIOThread.daemon = True
    userIOThread.start()

    # Go into our system loop
    system_loop(sys_sock)
