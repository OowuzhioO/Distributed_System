import socket
import threading
import json


intr_port = 5006


class Introducer(threading.Thread):
    def __init__(self, members, lock, timestamps):
        threading.Thread.__init__(self)
        self.lock = lock
        lock.acquire()
        self.members = members
        self.timestamps = timestamps
        lock.release()
    def run(self):
        sock = socket.socket(socket.AF_INET, # Internet
                         socket.SOCK_DGRAM) # UDP
        sock.bind(('', intr_port))

        while True:
            data, addr = sock.recvfrom(1024)
            if(data == "Leave"):
                break
            self.lock.acquire()
            sock.sendto(str(self.members), addr)
            sock.sendto(str(self.timestamps), addr)
            self.lock.release()

        print "Intro done"
