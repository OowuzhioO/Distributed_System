To get the network running, always start the introducer first using
 python failure_det.py
The process recognises the introducer by checking the hostname to determine it's ID.
Thereafter any process can join the network by running failure_det.py.

Input Options while the process is running:
Leave - Voluntarily leave the network
members - List all the members
id - To print the node's own ID
