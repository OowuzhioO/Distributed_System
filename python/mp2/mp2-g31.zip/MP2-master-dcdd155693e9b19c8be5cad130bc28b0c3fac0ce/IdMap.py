id_map = []

for i in range(1,11):
    val = "10" if i == 10 else "0"+str(i)
    id_map.append("fa17-cs425-g31-"+val+".cs.illinois.edu")
