import threading
import socket
import time
import sys
from datetime import datetime

UDP_PORT = 5005

class Receiver(threading.Thread):
    def __init__(self, myId, member_list, neighbors, updates, comm, lock, timestamps):
        threading.Thread.__init__(self)
        lock.acquire()
        self.myId = myId
        self.member_list = member_list
        self.neighbors = neighbors
        self.updates = updates
        self.comm = comm
        self.timestamps = timestamps
        lock.release()
        self.lock = lock

    def processData(self, data):
        index = 0
        self.lock.acquire()
        while index < len(data):
            machineId = int(data[index])
            mesgType = int(data[index+1])

            # handle a regular heartbeat messsage
            if mesgType == 0:
                if machineId in self.neighbors:
                    self.neighbors[machineId] = time.time()
                index += 2

            # handle a join message
            elif mesgType == 1:
                timestamp = time.asctime(time.localtime((float)(data[index+2])))
                if (self.member_list[machineId] == 1):
                    pass
                else:
                    print str(datetime.now()), "Machine", machineId, "joined the network at ", timestamp
                    self.member_list[machineId] = 1
                    self.timestamps[machineId] = timestamp
                    self.updates[0] += data[index] + " " + data[index+1] + " " + data[index+2] + " "
                index += 3

            # handle a leave message
            elif mesgType == 2:
                if (self.member_list[machineId] == 0):
                    pass
                else:
                    print str(datetime.now()), "Machine", machineId, "voluntarily left the network"
                    self.member_list[machineId] = 0
                    self.updates[0] += data[index] + " " + data[index+1] + " "
                index += 2

            # handle a failure message
            elif mesgType == 3:
                if (self.member_list[machineId] == 0):
                    pass
                else:
                    print str(datetime.now()), "Machine", machineId, "unexpectedly left the network"
                    self.member_list[machineId] = 0
                    self.updates[0] += data[index] + " " + data[index+1] + " "
                index += 2
            else:
                print "Unexpected system in the network. Bye"
                sys.exit()
        self.lock.release()

    def run(self):
        # should send heartbeats in loop
        # quits loop when it decides to leave, but sends leave messages first

        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.bind(('',UDP_PORT))
        while (self.comm != "Leave"):
            # TODO: accept UDP messages
            # TODO: wait for/parse UDP messages
            data = sock.recv(1024)
            if (data == "Leave"):
                self.lock.acquire()
                self.updates[0] += " " + str(self.myId) + " 2"
                self.lock.release()
                break
            elif (data == "Crash"):
                print "Leaving because of a false positive"
                self.lock.acquire()
                self.neighbors["crash"] = True
                self.lock.release()
                break
            data = data.strip().split(' ')


            t = threading.Thread(target = self.processData, args=(data,))
            t.start()

        print str(datetime.now()), "Receiver Done"
