import socket
import random

class MySocket():
	def __init__(self, var1, var2):
        	self.s = socket.socket(var1, var2)
		self.droprate =	0
			
	def sendto(self, arg1, arg2):
		x = random.randint(1,100)		
		if (x>=self.droprate):
        		self.s.sendto(arg1, arg2)
		else:		
			print ("Dropped packet. Oops")
