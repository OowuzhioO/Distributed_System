import threading
import MySocket
import socket
import time
import sys
from datetime import datetime

from IdMap import *




class HeartBeater(threading.Thread):
   def __init__(self, myId, member_list, neighbors, updates, comm, lock):
      threading.Thread.__init__(self)
      lock.acquire()
      self.myId = myId
      self.member_list = member_list
      self.neighbors = neighbors
      self.updates = updates
      self.comm = comm
      lock.release()
      self.lock = lock


   # Function to replace a neighbor if it has failed
   def replaceNeighbor(self, added):
       # traverse one node towards left and then one towards right
       for i in range(1,6):
           ind = (self.myId - i) % 10
           # if this server is not already being heartbeated to and the server
           # is on
           if ind not in self.neighbors and ind not in added and self.member_list[ind] == 1:
               return ind
           ind = (self.myId + i) % 10
           # if this server is not already being heartbeated to and the server
           # is on
           if ind not in self.neighbors and self.member_list[ind] == 1:
               return ind

   # Function to find the nearest live neighbors of the node
   def findNeighbors(self):
       processes = []
       myIndex = 0
       for i in range(0,10):
           if i == self.myId:
               myIndex = len(processes)
           if abs(self.member_list[i]) == 1:
               processes.append(i)
       dists = []
       for index in range(len(processes)):
           process = processes[index]
           dist = abs(index - myIndex)
           dist = min(dist, len(processes) - dist)
           if (dist != 0):
               dists.append((process, dist))
       dists =  sorted(dists, key = lambda t:t[1])

       inds = [ i[0] for i in dists]

       if len(inds) > 4:
           return inds[0:4]

       return inds

   # thread starting function
   def run(self):
      # send heartbeats in loop
      # quits loop when it decides to

      sock = MySocket.MySocket(socket.AF_INET, # Internet
                       socket.SOCK_DGRAM) # UDP

      while self.comm != "Leave":
          self.lock.acquire()
          # find new neighbors that may have recently joined, remove old neighbors
          # that are no longer nearest
          inds = self.findNeighbors()
          for i in inds:
              if i not in self.neighbors:
                  # set up a new neighbor (recently joined)
                  self.neighbors[i] = time.time()
          for_del = []
          for key in self.neighbors:
              if key not in inds:
                  for_del.append(key)
                  if (type(key) == str):
                      sys.exit()
                  if self.member_list[key] == -1:
                      self.member_list[key] = 0

          for key in for_del:
              del self.neighbors[key]

          # Check for neighbors that have failed, by comparing timestamps, replace
          # if necessary
          curr = time.time()

          for_del = set()
          new_neighs = set()

          # detect failed neighbors
          for k in self.neighbors:
              if curr - self.neighbors[k] > 5:
                  self.member_list[k] = 0
                  for_del.add(k)
                  new_Neighbour = self.replaceNeighbor(new_neighs)
                  if new_Neighbour is not None:
                      new_neighs.add(new_Neighbour)
              elif curr - self.neighbors[k] > 1.7 and self.member_list[k] == 1:
                  # server has timed out --> failure message
                  print str(datetime.now()), "I declare Machine", k, "unexpectedly left the network"
                  sock.sendto("Crash", (socket.gethostbyname(id_map[k]), 5005))
                  # update member list to show failure
                  self.member_list[k] = -1
                  # update neighbor list
                  self.updates[0] += str(k) + " 3 "


          # Replace neighbors as necessary
          for i in for_del:
              del self.neighbors[i]

          for i in new_neighs:
              self.neighbors[i] = time.time()

          val = (str(self.myId)+ " 0 " + self.updates[0].strip()).strip()
          for i in self.neighbors:
              sock.sendto(val, (socket.gethostbyname(id_map[i]), 5005))
          self.updates[0] = ""
          self.lock.release()
          time.sleep(0.5) # wait for heartbeat time


      # send leave message
      self.lock.acquire()
      for i in self.neighbors:
          val = str(self.myId)+ " 0 " + str(self.myId)+ " 2"
          sock.sendto(val, (socket.gethostbyname(id_map[i]), 5005))
      self.lock.release()

      print str(datetime.now()), "HB Done"
