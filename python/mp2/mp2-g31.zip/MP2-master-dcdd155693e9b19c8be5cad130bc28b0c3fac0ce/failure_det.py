import threading
import sys
import time
import socket
import json
from datetime import datetime

from HeartBeater import *
from introducer import *
from Receiver import *

from IdMap import *

updateLock = threading.Lock()


# server id
s_id = 0
myname = socket.gethostname()
if ("cs425" in myname):
    s_id = int(myname.split("-")[3].split(".")[0]) - 1
else:
    s_id = int(raw_input("Please enter int id"))

# make the member_list completely uninitialized, since this is a new node!
# 0 - member not running
# 1 - member running
# 2 - member list not initialized (adding this state just in case )
member_list = [2 for i in range(0,10)]
timestamps = [0 for i in range(0,10)]

# store update messages here.
# key will be the id of server, value is the message sent
# Possible values:
    # 0 - regular hearbeat
    # 1 - machine join message
    # 2 - machine leaves
    # 3 - machine fails

# key - id to connect with, value - most recent timestamp
neighbor_dict = {}
updates = [""]
comm = ""

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

intro = None


# Set up introducer if the server id is 0
if s_id == 0:
    success = False
    data = ""
    for i in id_map: 
        sock.sendto("get", (socket.gethostbyname(i), 5006))
        sock.settimeout(0.5)
        try:
            data = sock.recv(1024)
            timestamps = sock.recv(1024)
            success = True
            break
        except socket.timeout:
            continue
    sock.settimeout(None)
    member_list[0] = 1
    if (success is True):
	    timestamps = timestamps[1:-1]
	    timestamps = timestamps.split(", ")
	    member_list = json.loads(data)
	    print "Initial member list: "
	    for i in range(0, len(member_list)):
		if member_list[i] == 1:
                    print "Server", i, "is running. It joined at ", timestamps[i]
    intro = Introducer(member_list, updateLock, timestamps)
    intro.start()
else:
    # initialize member list
    sock.sendto("get", (socket.gethostbyname(id_map[0]), 5006))
    sock.settimeout(2.0)
    try:
        data = sock.recv(1024)
        timestamps = sock.recv(1024)
    except socket.timeout:
        print str(datetime.now()), "Cannot join network as introducer is down"
        sys.exit()
    timestamps = timestamps[1:-1]
    timestamps = timestamps.split(", ")
    sock.settimeout(None)
    member_list = json.loads(data)
    print "Initial member list: "
    for i in range(0, len(member_list)):
        if member_list[i] == 1:
	    print "Server", i, "is running. It joined at ", timestamps[i]
    member_list[s_id] = 1
    intro = Introducer(member_list, updateLock, timestamps)
    intro.start()


# Initialize update string to be sent between nodes
currTime = time.time()
updates[0] += " " + str(s_id) + " 1 " + str(currTime)
timestamps[s_id] = time.asctime(time.localtime(currTime))

# start the receiver thread
rec = Receiver(s_id, member_list, neighbor_dict, updates, comm, updateLock, timestamps)
rec.start()

# start heart beating thread
heart = HeartBeater(s_id, member_list, neighbor_dict, updates, comm, updateLock)
heart.start()

# Simple test: sock.sendto("1 1 1.1", ('', 5005))
while comm != "Leave":
    comm = raw_input()
    if comm == "members":
        updateLock.acquire()
        print "Printing members:"
        for i in range(0, len(member_list)):
            if member_list[i] == 1:
                print "Server", i, "is running. It joined at ", timestamps[i]
        updateLock.release()
    elif comm == "id":
        print "ID:", s_id, "I joined the network at ", timestamps[i]


sock.sendto("Leave", ('', 5005))
rec.join()

updateLock.acquire()
if "crash" in neighbor_dict:
    sys.exit()
updateLock.release()

heart.comm = "Leave"
heart.join()

sock.sendto("Leave", ('', 5006))
intro.join()
