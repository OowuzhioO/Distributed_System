#### README
### This is the readme file for fa2017 CS425 MP2 Group57{stang30, yumochi2}

1. requirements 
	This submission is written in python 2.7 and bash, so there is no need to compile anything. 

2. running the main code ## 
	mp2.py is the main script to run failure detectors on an extended ring style heartbeat system. Nodes are treated as servers and specific servers are designated as introducers. Logs will be stored in a log file using python `logging` module, default store log file name is `FD.log`.  

	For the rest of code we assume you are in `$cs425_MP2` as `$ROOT` directory.  
	1 To run the failure detector system, login to one VM and use command `$ROOT$python mp2.py` on any of the VMs.  
	2 A series of arguments can be added to set parameters when running mp2.py
	
        1. Use -p to set port for the nodes, use as `$ROOT$python mp2.py -p 4141`. Default value is 8001.
	    2. Use -v to set logfile to record debug information in the VMS, use as `$ROOT$python mp2.py -v`.
	    3. Use -c to set remove previous logfiles in the VMS, use as `$ROOT$python mp2.py -c`.
	    4. Use -T to set tFail time for the nodes. This is failure time and clean up time for the detectors. Use as `$ROOT$python mp2.py -T 1.4`. Default value is 1.5.
	    5. Use -t to set tick for the nodes. Heartbeat rate is 1/3 of tick amount. Use as `$ROOT$python mp2.py -t 0.3`. Default value is 0.5.
	    6. Use -n to set number of neighbors for nodes. This correlate to predcessors and successors. Use as `$ROOT$python mp2.py -n 2`. Default value is 3.
	    7. Use -r to set threshold to simulate % of droprate. Use as `$ROOT$python mp2.py -r 0.04`. Default value is 0.

3. run and kill processe on mutiple VMs with one script  
	We also provide a bash script `demo.sh` to start screen process to access `mp2.py` on multiple VMs. To use this script:  

	1 first change variable `$U` to change username using first argument as `$ROOT$ ./demo.sh tomChang21` .
	
	2 commment/uncommnet variable `$NUM` to specify which set of VMs you want to operate.  
	
	3 use second argument to set operation as shown below.
	
	    1. `$ROOT$ ./demo.sh username start` will start failure detection servers on target VMs.
	    2. `$ROOT$ ./demo.sh username join` will allow target VMs to join group.
	    3. `$ROOT$ ./demo.sh username leave` will cause target VMs to leave group.
	    4. `$ROOT$ ./demo.sh username memb` will will print members visible on membership list in target VMs.
	    5. `$ROOT$ ./demo.sh username self` will print target VMs own id.
	    6. `$ROOT$ ./demo.sh username misc` will print entire membership lists on target VMs.
	    7. `$ROOT$ ./demo.sh username kill` will kill target VMs.
	    8. `$ROOT$ screen -r nodexx` will bring view into each specified VM's user interface. 
