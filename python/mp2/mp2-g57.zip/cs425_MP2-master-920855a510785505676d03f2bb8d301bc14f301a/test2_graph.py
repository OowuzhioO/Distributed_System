import socket
import json 
from collections import OrderedDict,defaultdict
import time
import random
import numpy as np

import pdb
import pprint

def createMemb(N):
	
	membList = defaultdict(dict)

	for i in range(1,N+1):
		tStamp = str(time.time())
		hostNameId = 'fa17-cs425-g57-%02d.cs.illinois.edu'%i + '_'+tStamp 		
		membList[hostNameId] = {'count': 0, 'localtime': time.time(), 'isFailure': False}
	return membList

def findNeighbors(n, hostNameId, membershipIds):
	# N find N succesors and N predisussors
	# input membershipIds must be a sorted list
	assert type(membershipIds) == list
	if sorted(membershipIds) != membershipIds:
		membershipIds = sorted(membershipIds)

	idx = membershipIds.index(hostNameId) if hostNameId in membershipIds else None

	if idx == None:
		membershipIds.append(hostNameId)
		membershipIds = sorted(membershipIds)
		idx = membershipIds.index(hostNameId)

	leng =  len(membershipIds)

	start = idx-n
	end = idx+n+1
	neighbors=[]


	for i in range(start,end):
		neighbors.append(membershipIds[i%leng])
	# pdb.set_trace()
	# neighbors = membershipIds[start:idx]+membershipIds[(idx+1)%leng:end]

	# final check neighbors, must not include duplicate members and host itself
	neighbors = [n for n in neighbors if n != hostNameId]
	neighbors = sorted(list(set(neighbors)))

	return neighbors




if __name__=='__main__':
	# case 1, 2N<M
	N = 3
	M = 10
	membList = createMemb(M)
	for j in range(0,15):
		this_node = 'fa17-cs425-g57-%02d.cs.illinois.edu'%j + '_'+str(time.time())
		neighbors = findNeighbors(N,this_node,sorted(membList.keys()))
		print j, len(neighbors)
		pprint.pprint(neighbors)

	# case 2, 2N>M
	N = 3
	M = 4
	membList = createMemb(M)
	for j in range(0,15):
		this_node = 'fa17-cs425-g57-%02d.cs.illinois.edu'%j + '_'+str(time.time())
		neighbors = findNeighbors(N,this_node,sorted(membList.keys()))
		print j, len(neighbors)
		pprint.pprint(neighbors)