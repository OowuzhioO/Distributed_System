import socket
import json 
from collections import OrderedDict,defaultdict
import time
import random
'''
default function to help set up json encoder
def default(self, o):
   try:
       iterable = iter(o)
   except TypeError:
       pass
   else:
       return list(iterable)
   # Let the base class default method raise the TypeError
   return json.JSONEncoder.default(self, o)'''

'''function to generate a simulated membership list'''
def createMemb():
	hostNames = []
	membList = defaultdict(dict)

	for i in range(3):
		hostNames.append('fa17-cs425-g57-%02d.cs.illinois.edu_%f'%i, %time.time()*1000)
		membList[hostNames[i]] = {'count': 0, 'localtime': time.time()*1000, 'isFailure': False}
	return membList

'''function to send a membList to a designated socket
 input: membList - a membership list
 (currently not working)''' 
def sendMembList(membList):

	UDP_IP = socket.gethostbyname(socket.gethostname())
	UDP_PORT = 8079

	rmtHostInfo = ('172.22.154.168', 8080)
	rmtHost = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
	rmtHost.bind(rmtHostInfo)

	em = json.JSONEncoder().encode(membList)
	sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM) # UDP
	sock.sendto(em, (rmtHostInfo))

	while True:
		data, addr = sock.recvfrom(1024) # buffer size is 1024 bytes
		print ("received confirmation on send")
		break

	sock.close()
	return data

'''function to randomly increment the count on a list
input: membList - a membership list to be altered'''
def increment(membList):
	hostNames = list(membList.keys())
	ri = random.choice(hostNames)
	membList[ri]['count'] += 1
	membList[ri]['localtime'] = time.time()*1000
	return membList

'''function to update our membList
input: 	membList - the membership list to be update
		nmembList - the membership list containing information to be updated 
					to our membership list'''
def update(membList, nmembList):
	for i in nmembList:
			if i in membList:
				# if incoming sequence counter is higher then update local time
				if nmembList[i]['count'] > membList[i]['count']:
					membList[i]['localtime'] = time.time()*1000;
			else:
				membList[i] = {'count': nmembList[i]['count'], 'localtime': time.time()*1000, 'isFailure': nmembList[i]['isFailure']}
	for i in membList:
		if (time.time()*1000 - membList[i]['localtime']) >= 10:
			membList[i]['isFailure'] = True
		elif membList[i]['isFailure']:
			del membList[i]
	return membList

'''function to recieve information from a designated server
(currently not working)'''
def recieve():
	UDP_IP = '172.22.154.168'
	UDP_PORT = 8079

	sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM) # UDP
	print ('in function')
	sock.bind((UDP_IP, UDP_PORT))
	print ('in function')


	while True:
		data, addr = sock.recvfrom(1024) # buffer size is 1024 bytes
		print "received message", data

	sock.close()


'''user interface to be used for 
	creating a membership list
	incrementing a membership list
	sending the membership list to another server
	printing current state to through output
	update membership list with recieved info from another server
	quit the program'''
membList = defaultdict(dict)
data = ''
while True:
	inp = raw_input('/create/increment/send/print/update/recieve/quit?')
	print(inp)
	if inp == 'create':
		membList = createMemb()
	elif inp == 'increment':
		try:
			membList = increment(membList)
		except:
			print('create membList first')
	elif inp == 'send':
		try:
			data = sendMembList(membList)
		except:
			print('create a membList first')
	elif inp == 'print':
		while True:
			inp1 = raw_input('membList/data?')
			if inp1 == 'membList':
				try:
					print(membList)
					break
				except:
					print('no membList exists')
					break
			elif inp1 == 'data':
				try:
					print(data)
					break
				except:
					print('no data exists')
					break
	elif inp == 'update':
		try:
			print('Loading Data')
			receivedMembList = json.loads(data)
			print('Encode receivedMembList to print')
			ea = json.JSONEncoder(indent = 1).encode(receivedMembList)
			membList = update(membList, receivedMembList)
		except:
			print('data not received') 
	elif inp == 'recieve':
		# try:
			recieve()
		# except:
		# 	print ("problem encountered")
	elif inp == 'quit':
		break