#!/bin/bash

# bash script for demo

U=$1 # user name on host
OP=$2 # operation

# unfortunately you need to manually setup nodes to operate
# declare -a NUM=('01' '02' '03' '04' '05' '06' '07' '08' '09' '10')
# declare -a NUM=('01' '02' '03' '04')
# declare -a NUM=('07' '06' '05')
# declare -a NUM=('08' '09' '10')
# declare -a NUM=('07' '06' '05' '08' '09' '10')

# node to terminate
# declare -a NUM=('05')
# declare -a NUM=('01' '02' '03' '04' '06' '07' '08' '09' '10')

# declare -a NUM=('06' '08' '10')
# declare -a NUM=('01' '02' '03' '04' '07' '09' )

# node to rejoin
# declare -a NUM=('05' '06' '08' '10')
declare -a NUM=('01' '02' '03' '04' '05' '06' '07' '08' '09' '10')

#kill screen sessions
if [ "$OP" = 'kill' ]; then
	echo "kill sessions"
	screen -ls | grep Detached | cut -d. -f1 | awk '{print $1}' | xargs kill
	exit 1
fi

# run FD
for i in "${NUM[@]}"
do

  v=$[100 + (RANDOM % 100)]$[1000 + (RANDOM % 1000)]
  v=$[RANDOM % 5].${v:1:2}${v:4:3}
  echo "sleep for "$v 'seconds'
  sleep $v

  echo "processing node $i"
  host='fa17-cs425-g57-'"$i"'.cs.illinois.edu'
  screenId='node'$i

  case "$OP" in
            'start')
            echo 'node'$i ' starts '
            # customize screen logfile name fo each node
            echo 'logfile ./FD_log/screenlog.'$i >/tmp/screenrc
                               
            screen -c /tmp/screenrc -L -S $screenId -d -m ssh $U@$host "cd cs425_MP2 && python -u mp2.py -p 7667 -v -c -T 1.9 -t 1.3 -n 3"
            rm /tmp/screenrc
            ;;

            'join')
            echo 'node'$i ' joins group'
            screen -S $screenId -p 0 -X stuff "join^M"
            ;;

            'leave')
            echo 'node'$i ' leaves group'
            screen -S $screenId -p 0 -X stuff "leave^M"
            ;;

            'memb')
            echo 'listing membership list in node'$i
            screen -S $screenId -p 0 -X stuff "memb^M"
            ;;

            'self')
            echo 'listing self in node'$i
            screen -S $screenId -p 0 -X stuff "self^M"
            ;;

            'misc')
            echo 'listing misc info in node'$i
            screen -S $screenId -p 0 -X stuff "misc^M"
            ;;

            *)
                echo $"Usage: $0 {start|join|leave|memb|self|misc|kill}"
                exit 1
  esac

done

## using screen to controle many VM processes
# screen -S node01 -d -m ssh stang30@fa17-cs425-g57-01.cs.illinois.edu "cd cs425_MP2 && python -u mp2.py"

# example to run remote fd program and input from local machine
# ssh stang30@fa17-cs425-g57-01.cs.illinois.edu "cd cs425_MP2 && python -u mp2.py"
# ssh stang30@fa17-cs425-g57-02.cs.illinois.edu "cd cs425_MP2 && python -u mp2.py"


## kill all detached screen sessions
# screen -ls | grep Detached | cut -d. -f1 | awk '{print $1}' | xargs kill